
Project Member

1. Purinat 	Sanbundit	6088159
2. Surachet 	Yuktiratna	6088235

	Roles
Purinat		: 	Struct the base functions and overall structures. Doing the basic
			multithreads. Tester.

Surachet	: 	Do in logic part of the programs example how the robots check the 
			another robots in the process working or not. Debugger.